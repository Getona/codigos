from rest_framework import viewsets
from .models import Professor, Disciplina, ReservaAmbiente
from .serializers import ProfessorSerializer, DisciplinaSerializer, ReservaAmbienteSerializer

class ProfessorViewSet(viewsets.ModelViewSet):
    queryset = Professor.objects.all()
    serializer_class = ProfessorSerializer

class DisciplinaViewSet(viewsets.ModelViewSet):
    queryset = Disciplina.objects.all()
    serializer_class = DisciplinaSerializer

class ReservaAmbienteViewSet(viewsets.ModelViewSet):
    queryset = ReservaAmbiente.objects.all()
    serializer_class = ReservaAmbienteSerializer
