from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import ProfessorViewSet, DisciplinaViewSet, ReservaAmbienteViewSet

router = DefaultRouter()
router.register(r'professores', ProfessorViewSet)
router.register(r'disciplinas', DisciplinaViewSet)
router.register(r'reservas', ReservaAmbienteViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
